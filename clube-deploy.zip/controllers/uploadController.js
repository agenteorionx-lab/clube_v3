const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.resolve(__dirname, '../clube.db');
const db = new sqlite3.Database(dbPath);
const multer = require('multer');
const fs = require('fs');

// Configure Multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const dir = path.join(__dirname, '../public/uploads');
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        // Use timestamp + random + extension
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'photo-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

exports.uploadMiddleware = upload.single('photo');

exports.updatePhoto = (req, res) => {
    const userId = req.userId; // From Auth Middleware
    const showPhoto = req.body.showPhoto === 'true' || req.body.showPhoto === true ? 1 : 0;

    let photoUrl = null;
    if (req.file) {
        photoUrl = '/uploads/' + req.file.filename;
    }

    // Update Client table linked to this User
    // If photo matches, update photo_url. Always update show_photo.

    let query = "";
    let params = [];

    if (photoUrl) {
        query = "UPDATE clients SET photo_url = ?, show_photo = ? WHERE user_id = ?";
        params = [photoUrl, showPhoto, userId];
    } else {
        query = "UPDATE clients SET show_photo = ? WHERE user_id = ?";
        params = [showPhoto, userId];
    }

    db.run(query, params, function (err) {
        if (err) {
            return res.status(500).json({ message: 'Erro ao atualizar foto/configurações.' });
        }
        res.json({ message: 'Dados atualizados com sucesso!', photoUrl: photoUrl });
    });
};
