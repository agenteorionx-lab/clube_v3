const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.resolve(__dirname, '../clube.db');
const db = new sqlite3.Database(dbPath);

exports.getMyData = (req, res) => {
    const userId = req.userId; // From JWT middleware

    // Retrieve client record associated with this user
    const query = `
        SELECT c.*, s.status, s.next_due_date, s.start_date, u.email
        FROM clients c
        LEFT JOIN subscriptions s ON c.id = s.client_id
        JOIN users u ON c.user_id = u.id
        WHERE c.user_id = ?
    `;

    db.get(query, [userId], (err, client) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao buscar dados do cliente' });
        }
        if (!client) {
            return res.status(404).json({ message: 'Dados de cliente não encontrados para este usuário.' });
        }
        res.json(client);
    });
};

exports.updateMyData = (req, res) => {
    const userId = req.userId;
    const { email, phone, password } = req.body;
    const bcrypt = require('bcrypt');

    db.serialize(() => {
        db.run("BEGIN TRANSACTION");

        // 1. Update User (Email, Password)
        if (email || password) {
            let userSql = "UPDATE users SET ";
            const userParams = [];
            if (email) {
                userSql += "email = ?, ";
                userParams.push(email);
            }
            if (password) {
                const salt = bcrypt.genSaltSync(10);
                const hash = bcrypt.hashSync(password, salt);
                userSql += "password_hash = ?, force_password_change = 0, ";
                userParams.push(hash);
            }
            userSql = userSql.slice(0, -2); // Remove trailing comma
            userSql += " WHERE id = ?";
            userParams.push(userId);

            db.run(userSql, userParams, function (err) {
                if (err) {
                    console.error('Update User Error:', err);
                    db.run("ROLLBACK");
                    return res.status(500).json({ message: 'Erro ao atualizar dados de login' });
                }
            });
        }

        // 2. Update Client (Phone)
        if (phone) {
            db.run("UPDATE clients SET phone = ? WHERE user_id = ?", [phone, userId], function (err) {
                if (err) {
                    console.error('Update Client Error:', err);
                    db.run("ROLLBACK");
                    return res.status(500).json({ message: 'Erro ao atualizar telefone' });
                }
            });
        }

        db.run("COMMIT", function (err) {
            if (err) {
                return res.status(500).json({ message: 'Erro ao confirmar atualização' });
            }
            res.json({ message: 'Dados atualizados com sucesso' });
        });
    });
};
