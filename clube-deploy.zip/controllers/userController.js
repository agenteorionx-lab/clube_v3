const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
const dbPath = path.resolve(__dirname, '../clube.db');
const db = new sqlite3.Database(dbPath);

exports.list = (req, res) => {
    // Exclude clients from this list. They appear separately.
    db.all("SELECT id, name, email, role, created_at FROM users WHERE role != 'cliente'", [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao listar usuários' });
        }
        res.json(rows);
    });
};

exports.create = (req, res) => {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios' });
    }

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);
    // Force role to be 'funcionario' unless specified (admin creates admin?)
    // Let's allow admin to choose role, default to funcionario
    const userRole = role || 'funcionario';

    db.run("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
        [name, email, hash, userRole],
        function (err) {
            if (err) {
                return res.status(500).json({ message: 'Erro ao criar usuário. Email já existe?' });
            }
            res.status(201).json({ message: 'Usuário criado com sucesso', id: this.lastID });
        }
    );
};

exports.delete = (req, res) => {
    const id = req.params.id;
    // Prevent deleting self? Maybe frontend handles it.
    db.run("DELETE FROM users WHERE id = ?", [id], function (err) {
        if (err) return res.status(500).json({ message: 'Erro ao excluir usuário' });
        res.json({ message: 'Usuário excluído com sucesso' });
    });
};
