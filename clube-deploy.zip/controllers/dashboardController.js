const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.resolve(__dirname, '../clube.db');
const db = new sqlite3.Database(dbPath);

exports.getStats = (req, res) => {
    // 1. Counts by Status
    const queryCounts = `
        SELECT status, COUNT(*) as count 
        FROM subscriptions 
        GROUP BY status
    `;

    // 2. Revenue Forecast (Sum of value of all active/pendente clients)
    // Assuming 'pendente' will pay, and 'ativo' already paid (or is paying monthly).
    // Let's sum 'ativo' and 'pendente' as "Expected/Recurring Revenue".
    const queryRevenue = `
        SELECT SUM(c.value) as total 
        FROM clients c 
        JOIN subscriptions s ON c.id = s.client_id 
        WHERE s.status IN ('ativo', 'pendente')
    `;

    db.all(queryCounts, [], (err, rows) => {
        if (err) return res.status(500).json({ message: 'Erro nos stats' });

        const stats = {
            ativo: 0,
            pendente: 0,
            cancelado: 0,
            lead_inativo: 0
        };

        rows.forEach(row => {
            if (stats.hasOwnProperty(row.status)) {
                stats[row.status] = row.count;
            }
        });

        db.get(queryRevenue, [], (err, row) => {
            if (err) return res.status(500).json({ message: 'Erro na receita' });

            res.json({
                counts: stats,
                revenue: row ? row.total : 0
            });
        });
    });
};

exports.getReports = (req, res) => {
    // 1. Revenue by Month (last 6 months)
    // We'll use the subscriptions start_date or created_at. Let's use clients.created_at for simplicity of "new MRR"
    // Better: sum of clients.value grouped by strftime('%Y-%m', clients.created_at)

    const queryGrowth = `
        SELECT strftime('%Y-%m', created_at) as month, COUNT(id) as new_clients, SUM(value) as new_revenue
        FROM clients
        GROUP BY month
        ORDER BY month DESC
        LIMIT 12
    `;

    // 2. Clients by Plan
    const queryPlans = `
        SELECT plan, COUNT(*) as count
        FROM clients
        GROUP BY plan
    `;

    // 3. Status Distribution (overall health)
    const queryStatus = `
        SELECT status, COUNT(*) as count 
        FROM subscriptions 
        GROUP BY status
    `;

    db.all(queryGrowth, [], (err, growthData) => {
        if (err) return res.status(500).json({ message: 'Erro ao buscar crescimento' });

        db.all(queryPlans, [], (err, plansData) => {
            if (err) return res.status(500).json({ message: 'Erro ao buscar planos' });

            db.all(queryStatus, [], (err, statusData) => {
                if (err) return res.status(500).json({ message: 'Erro ao buscar status' });

                res.json({
                    growth: growthData.reverse(), // reverse to show chronological order
                    plans: plansData,
                    status: statusData
                });
            });
        });
    });
};
