const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
const dbPath = path.resolve(__dirname, '../clube.db');
const db = new sqlite3.Database(dbPath);

exports.list = (req, res) => {
    // Get clients with their latest subscription status
    const query = `
        SELECT c.*, s.status, s.next_due_date, s.start_date
        FROM clients c
        LEFT JOIN subscriptions s ON c.id = s.client_id
    `;

    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Erro ao buscar clientes' });
        }
        res.json(rows);
    });
};

exports.create = (req, res) => {
    // Now expects email (for login) and password (optional, default to CPF?)
    // Let's assume the form sends email. If not, maybe use CPF as email fake? No, better ask for email.
    // For now, let's auto-generate a login based on Email provided in form.
    const { name, cpf, phone, plan, value, address, email } = req.body;

    if (!email) {
        return res.status(400).json({ message: 'Email é obrigatório para o login do cliente.' });
    }

    const password = cpf.replace(/\D/g, ''); // Default password is CPF numbers
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);

    db.serialize(() => {
        db.run("BEGIN TRANSACTION");

        // 1. Create User
        db.run("INSERT INTO users (name, email, password_hash, role, force_password_change) VALUES (?, ?, ?, ?, 1)",
            [name, email, hash, 'cliente'],
            function (err) {
                if (err) {
                    db.run("ROLLBACK");
                    return res.status(500).json({ message: 'Erro ao criar usuário do cliente. Email já existe?' });
                }

                const userId = this.lastID;

                // 2. Create Client linked to User
                const stmtClient = db.prepare("INSERT INTO clients (user_id, name, cpf, phone, plan, value, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
                stmtClient.run([userId, name, cpf, phone, plan, value, address], function (err) {
                    if (err) {
                        db.run("ROLLBACK");
                        return res.status(500).json({ message: 'Erro ao criar cliente. CPF já existe?' });
                    }

                    const clientId = this.lastID;
                    const today = new Date();
                    const nextDue = new Date();
                    nextDue.setDate(today.getDate() + 30);

                    // 3. Create Subscription
                    const stmtSub = db.prepare("INSERT INTO subscriptions (client_id, start_date, next_due_date, status) VALUES (?, ?, ?, ?)");
                    stmtSub.run([clientId, today.toISOString().split('T')[0], nextDue.toISOString().split('T')[0], 'pendente'], function (err) {
                        if (err) {
                            db.run("ROLLBACK");
                            return res.status(500).json({ message: 'Erro ao criar assinatura' });
                        }

                        db.run("COMMIT");
                        res.status(201).json({ message: 'Cliente e Login criados com sucesso. Senha padrão é o CPF (apenas números).', id: clientId });
                    });
                    stmtSub.finalize();
                });
                stmtClient.finalize();
            }
        );
    });
};

exports.confirmPayment = (req, res) => {
    const clientId = req.params.id;

    // Logic: Status -> 'ativo', next_due_date += 30 days
    db.get("SELECT * FROM subscriptions WHERE client_id = ?", [clientId], (err, sub) => {
        if (err || !sub) return res.status(404).json({ message: 'Assinatura não encontrada' });

        const currentDueDate = new Date(sub.next_due_date);
        const today = new Date();

        // If already overdue, maybe reset from today? Or just add 30 days to the old date?
        // Usually, if overdue, you pay for the period you missed OR you restart.
        // Simple logic: New due date = Today + 30 days (Renovated from payment moment)
        // OR New due date = Old Due Date + 30 days (if keeping strict cycle)

        // Requirement: "A data de vencimento é renovada para +30 dias."
        // Let's assume +30 days from NOW to ensure they have a full month of active status.
        // OR if it's a strict cycle, add to the old date. 
        // Let's use Today + 30 days to be safe for "Ativo" status guarantee.

        const newDueDate = new Date();
        newDueDate.setDate(newDueDate.getDate() + 30);

        db.run("UPDATE subscriptions SET status = ?, next_due_date = ? WHERE client_id = ?",
            ['ativo', newDueDate.toISOString().split('T')[0], clientId],
            (err) => {
                if (err) return res.status(500).json({ message: 'Erro ao confirmar pagamento' });
                res.json({ message: 'Pagamento confirmado', newDueDate: newDueDate });
            }
        );
    });
};

exports.delete = (req, res) => {
    const clientId = req.params.id;

    db.get("SELECT user_id FROM clients WHERE id = ?", [clientId], (err, row) => {
        if (err || !row) return res.status(404).json({ message: 'Cliente não encontrado' });

        const userId = row.user_id;

        db.serialize(() => {
            db.run("BEGIN TRANSACTION");

            // 1. Delete Subscriptions (Cascade might handle this, but let's be explicit)
            db.run("DELETE FROM subscriptions WHERE client_id = ?", [clientId], (err) => {
                if (err) {
                    db.run("ROLLBACK");
                    return res.status(500).json({ message: 'Erro ao excluir assinaturas' });
                }

                // 2. Delete Client
                db.run("DELETE FROM clients WHERE id = ?", [clientId], (err) => {
                    if (err) {
                        db.run("ROLLBACK");
                        return res.status(500).json({ message: 'Erro ao excluir cliente' });
                    }

                    // 3. Delete User
                    db.run("DELETE FROM users WHERE id = ?", [userId], function (err) {
                        if (err) {
                            db.run("ROLLBACK");
                            return res.status(500).json({ message: 'Erro ao excluir usuário associado' });
                        }

                        db.run("COMMIT", function (err) {
                            if (err) return res.status(500).json({ message: 'Erro ao commitar exclusão' });
                            res.json({ message: 'Cliente e usuário excluídos com sucesso' });
                        });
                    });
                });
            });
        });
    });
};

exports.update = (req, res) => {
    const clientId = req.params.id;
    const { name, cpf, phone, plan, status, next_due_date } = req.body;
    console.log(`[UPDATE] Client ${clientId}:`, req.body);

    db.serialize(() => {
        db.run("BEGIN TRANSACTION");

        // 1. Update Client Info
        db.run("UPDATE clients SET name = ?, cpf = ?, phone = ?, plan = ? WHERE id = ?",
            [name, cpf, phone, plan, clientId],
            function (err) {
                if (err) {
                    console.error('[UPDATE] Client Error:', err);
                    db.run("ROLLBACK");
                    return res.status(500).json({ message: 'Erro ao atualizar dados do cliente: ' + err.message });
                }

                // 2. Update Subscription Status/Dates if provided
                if (status || next_due_date) {
                    let subSql = "UPDATE subscriptions SET ";
                    const subParams = [];
                    if (status) {
                        subSql += "status = ?, ";
                        subParams.push(status);
                    }
                    if (next_due_date) {
                        subSql += "next_due_date = ?, ";
                        // Ensure date format or null check
                        subParams.push(next_due_date);
                    }
                    subSql = subSql.slice(0, -2); // remove comma
                    subSql += " WHERE client_id = ?";
                    subParams.push(clientId);

                    console.log('[UPDATE] Sub SQL:', subSql, subParams);

                    db.run(subSql, subParams, function (err) {
                        if (err) {
                            console.error('[UPDATE] Subscription Error:', err);
                            db.run("ROLLBACK");
                            return res.status(500).json({ message: 'Erro ao atualizar assinatura: ' + err.message });
                        }
                        db.run("COMMIT");
                        res.json({ message: 'Cliente atualizado com sucesso' });
                    });
                } else {
                    db.run("COMMIT");
                    res.json({ message: 'Dados do cliente atualizados com sucesso' });
                }
            }
        );
    });
};
