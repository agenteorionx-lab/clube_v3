const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');

// Connect to SQLite database
const dbPath = path.resolve(__dirname, 'clube.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        initDb();
    }
});

function initDb() {
    db.serialize(() => {
        // 1. Users Table
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT CHECK(role IN ('admin', 'funcionario', 'cliente')) NOT NULL DEFAULT 'funcionario',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // 2. Clients Table
        db.run(`CREATE TABLE IF NOT EXISTS clients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            name TEXT NOT NULL,
            cpf TEXT UNIQUE NOT NULL,
            phone TEXT,
            plan TEXT NOT NULL,
            value REAL NOT NULL,
            address TEXT,
            photo_url TEXT,
            show_photo BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )`);

        // 3. Subscriptions Table
        db.run(`CREATE TABLE IF NOT EXISTS subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id INTEGER NOT NULL,
            start_date DATE NOT NULL,
            next_due_date DATE NOT NULL,
            status TEXT CHECK(status IN ('ativo', 'pendente', 'cancelado', 'lead_inativo')) NOT NULL DEFAULT 'pendente',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (client_id) REFERENCES clients (id) ON DELETE CASCADE
        )`);

        // Seed Admin User (if not exists)
        // Default: admin@clube.com / 123456
        const adminEmail = 'admin@clube.com';
        db.get("SELECT * FROM users WHERE email = ?", [adminEmail], (err, row) => {
            if (!row) {
                const salt = bcrypt.genSaltSync(10);
                const hash = bcrypt.hashSync('123456', salt);
                db.run("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
                    ['Administrador', adminEmail, hash, 'admin']);
                console.log('Admin user created: admin@clube.com / 123456');
            }
        });

        // Safe ADD COLUMN 
        db.run(`ALTER TABLE users ADD COLUMN force_password_change BOOLEAN DEFAULT 0`, (err) => {
            // Ignore if column already exists
        });
    });
}

module.exports = db;
